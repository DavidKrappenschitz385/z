-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Sep 15, 2025 at 12:41 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `leagues`
--

-- --------------------------------------------------------

--
-- Table structure for table `leagues`
--

CREATE TABLE `leagues` (
  `id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `sport_id` int(11) NOT NULL,
  `season` varchar(20) NOT NULL,
  `start_date` date NOT NULL,
  `end_date` date NOT NULL,
  `registration_deadline` date NOT NULL,
  `max_teams` int(11) DEFAULT 16,
  `rules` text DEFAULT NULL,
  `status` enum('draft','open','closed','active','completed') DEFAULT 'draft',
  `created_by` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `leagues`
--

INSERT INTO `leagues` (`id`, `name`, `sport_id`, `season`, `start_date`, `end_date`, `registration_deadline`, `max_teams`, `rules`, `status`, `created_by`, `created_at`) VALUES
(1, 'Marc', 2, '2', '2025-08-20', '2025-08-30', '2025-08-14', 14, 'foul sunggo', 'draft', 1, '2025-08-09 05:35:31'),
(2, 'Marc', 2, '2', '2025-08-20', '2025-08-30', '2025-08-14', 14, 'foul sunggo', 'draft', 1, '2025-08-09 05:35:35'),
(3, 'SK LEAGUE', 2, '7', '2025-09-08', '2025-11-07', '2025-08-16', 10, 'FOUL SUNGGO', 'active', 1, '2025-08-09 19:27:05'),
(4, 'wqewqe', 1, 'wqewqe', '2025-08-28', '2025-09-04', '2025-08-14', 16, 'wewe', 'draft', 1, '2025-08-09 20:13:50'),
(5, 'wqewqe', 1, 'wqewqe', '2025-08-28', '2025-09-04', '2025-08-14', 16, 'wewe', 'draft', 1, '2025-08-09 20:13:59'),
(6, 'xx', 2, 'x', '2025-08-20', '2025-08-20', '2025-08-11', 16, 'xxx', 'draft', 1, '2025-08-10 06:07:59'),
(7, 'xx', 2, 'x', '2025-08-20', '2025-08-20', '2025-08-11', 16, 'xxx', 'draft', 1, '2025-08-10 06:09:56'),
(8, 'xx', 2, 'x', '2025-08-20', '2025-08-20', '2025-08-11', 16, 'xxx', 'draft', 1, '2025-08-10 06:10:29'),
(9, 'xx', 2, 'x', '2025-08-20', '2025-08-20', '2025-08-11', 16, 'xxx', 'draft', 1, '2025-08-10 06:11:02'),
(10, 'xxx', 1, 'xx', '2025-08-20', '2025-08-19', '2025-08-05', 16, 'xxx', 'draft', 1, '2025-08-10 06:11:39'),
(11, 'Sugbo Cup League', 2, '12', '2025-08-29', '2025-09-03', '2025-08-23', 15, 'No hard feelings', 'draft', 1, '2025-08-21 13:40:20'),
(12, 'Sugbo Cup League', 2, '12', '2025-08-29', '2025-09-03', '2025-08-23', 15, 'No hard feelings', 'draft', 1, '2025-08-21 13:40:49'),
(13, 'Sugbo Cup League', 2, '12', '2025-08-29', '2025-09-03', '2025-08-23', 15, 'No hard feelings', 'active', 1, '2025-08-21 13:41:43'),
(14, 'SK LEAGUE FOR NEWBIES', 2, '1', '2025-09-11', '2025-09-27', '2025-09-27', 10, 'JUST PLAY FOR FUN', 'draft', 1, '2025-09-09 01:11:46'),
(15, 'SK LEAGUE FOR NEWBIES', 2, '1', '2025-09-11', '2025-09-27', '2025-09-27', 10, 'JUST PLAY FOR FUN', 'active', 1, '2025-09-09 01:11:50');

-- --------------------------------------------------------

--
-- Table structure for table `matches`
--

CREATE TABLE `matches` (
  `id` int(11) NOT NULL,
  `league_id` int(11) NOT NULL,
  `home_team_id` int(11) NOT NULL,
  `away_team_id` int(11) NOT NULL,
  `venue_id` int(11) DEFAULT NULL,
  `match_date` datetime NOT NULL,
  `home_score` int(11) DEFAULT NULL,
  `away_score` int(11) DEFAULT NULL,
  `status` enum('scheduled','in_progress','completed','cancelled','postponed') DEFAULT 'scheduled',
  `notes` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `notifications`
--

CREATE TABLE `notifications` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `message` text NOT NULL,
  `type` enum('info','warning','success','error') DEFAULT 'info',
  `is_read` tinyint(1) DEFAULT 0,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `notifications`
--

INSERT INTO `notifications` (`id`, `user_id`, `title`, `message`, `type`, `is_read`, `created_at`) VALUES
(1, 1, 'Logged Out', 'You have successfully logged out.', 'info', 0, '2025-08-09 05:06:56'),
(2, 1, 'Welcome Back!', 'You have successfully logged in.', 'success', 0, '2025-08-09 05:17:01'),
(3, 1, 'Logged Out', 'You have successfully logged out.', 'info', 0, '2025-08-09 05:19:57'),
(4, 1, 'Welcome Back!', 'You have successfully logged in.', 'success', 0, '2025-08-09 05:20:04'),
(5, 1, 'Logged Out', 'You have successfully logged out.', 'info', 0, '2025-08-09 05:23:01'),
(6, 1, 'Welcome Back!', 'You have successfully logged in.', 'success', 0, '2025-08-09 05:24:45'),
(7, 1, 'Logged Out', 'You have successfully logged out.', 'info', 0, '2025-08-09 05:27:04'),
(8, 1, 'Welcome Back!', 'You have successfully logged in.', 'success', 0, '2025-08-09 05:27:12'),
(9, 1, 'Logged Out', 'You have successfully logged out.', 'info', 0, '2025-08-09 05:46:07'),
(10, 1, 'Welcome Back!', 'You have successfully logged in.', 'success', 0, '2025-08-09 06:34:38'),
(11, 1, 'Welcome Back!', 'You have successfully logged in.', 'success', 0, '2025-08-09 15:53:20'),
(12, 1, 'Logged Out', 'You have successfully logged out.', 'info', 0, '2025-08-09 15:54:41'),
(13, 2, 'Welcome Back!', 'You have successfully logged in.', 'success', 0, '2025-08-09 15:54:57'),
(14, 2, 'Logged Out', 'You have successfully logged out.', 'info', 0, '2025-08-09 15:55:25'),
(15, 1, 'Welcome Back!', 'You have successfully logged in.', 'success', 0, '2025-08-09 15:55:32'),
(16, 1, 'Logged Out', 'You have successfully logged out.', 'info', 0, '2025-08-09 15:58:40'),
(17, 2, 'Welcome Back!', 'You have successfully logged in.', 'success', 0, '2025-08-09 16:01:27'),
(18, 2, 'Logged Out', 'You have successfully logged out.', 'info', 0, '2025-08-09 16:05:19'),
(19, 1, 'Welcome Back!', 'You have successfully logged in.', 'success', 0, '2025-08-09 16:05:28'),
(20, 1, 'Logged Out', 'You have successfully logged out.', 'info', 0, '2025-08-09 16:29:25'),
(21, 1, 'Welcome Back!', 'You have successfully logged in.', 'success', 0, '2025-08-09 17:08:13'),
(22, 1, 'Logged Out', 'You have successfully logged out.', 'info', 0, '2025-08-09 17:13:12'),
(23, 2, 'Welcome Back!', 'You have successfully logged in.', 'success', 0, '2025-08-09 17:13:24'),
(24, 2, 'Logged Out', 'You have successfully logged out.', 'info', 0, '2025-08-09 17:29:01'),
(25, 1, 'Welcome Back!', 'You have successfully logged in.', 'success', 0, '2025-08-09 19:18:05'),
(26, 1, 'Logged Out', 'You have successfully logged out.', 'info', 0, '2025-08-09 19:25:58'),
(27, 1, 'Welcome Back!', 'You have successfully logged in.', 'success', 0, '2025-08-09 19:26:05'),
(28, 1, 'Logged Out', 'You have successfully logged out.', 'info', 0, '2025-08-09 19:28:07'),
(29, 2, 'Welcome Back!', 'You have successfully logged in.', 'success', 0, '2025-08-09 19:28:24'),
(30, 2, 'Logged Out', 'You have successfully logged out.', 'info', 0, '2025-08-09 19:36:36'),
(31, 1, 'Welcome Back!', 'You have successfully logged in.', 'success', 0, '2025-08-09 19:36:50'),
(32, 1, 'Logged Out', 'You have successfully logged out.', 'info', 0, '2025-08-09 19:38:58'),
(33, 2, 'Welcome Back!', 'You have successfully logged in.', 'success', 0, '2025-08-09 19:39:07'),
(34, 2, 'Logged Out', 'You have successfully logged out.', 'info', 0, '2025-08-09 20:10:50'),
(35, 1, 'Welcome Back!', 'You have successfully logged in.', 'success', 0, '2025-08-09 20:10:58'),
(36, 1, 'Welcome Back!', 'You have successfully logged in.', 'success', 0, '2025-08-10 05:58:19'),
(37, 1, 'Logged Out', 'You have successfully logged out.', 'info', 0, '2025-08-10 06:00:04'),
(38, 2, 'Welcome Back!', 'You have successfully logged in.', 'success', 0, '2025-08-10 06:00:16'),
(39, 2, 'Logged Out', 'You have successfully logged out.', 'info', 0, '2025-08-10 06:04:41'),
(40, 1, 'Welcome Back!', 'You have successfully logged in.', 'success', 0, '2025-08-10 06:04:50'),
(41, 1, 'Logged Out', 'You have successfully logged out.', 'info', 0, '2025-08-10 06:06:53'),
(42, 1, 'Welcome Back!', 'You have successfully logged in.', 'success', 0, '2025-08-10 06:06:59'),
(43, 1, 'Welcome Back!', 'You have successfully logged in.', 'success', 0, '2025-08-13 03:35:36'),
(44, 1, 'Logged Out', 'You have successfully logged out.', 'info', 0, '2025-08-13 03:37:36'),
(45, 2, 'Welcome Back!', 'You have successfully logged in.', 'success', 0, '2025-08-13 03:37:46'),
(46, 1, 'Welcome Back!', 'You have successfully logged in.', 'success', 0, '2025-08-13 03:39:40'),
(47, 1, 'Logged Out', 'You have successfully logged out.', 'info', 0, '2025-08-13 03:41:22'),
(48, 2, 'Welcome Back!', 'You have successfully logged in.', 'success', 0, '2025-08-13 03:41:42'),
(49, 2, 'Logged Out', 'You have successfully logged out.', 'info', 0, '2025-08-13 03:50:45'),
(50, 2, 'Welcome Back!', 'You have successfully logged in.', 'success', 0, '2025-08-13 03:58:17'),
(51, 1, 'Welcome Back!', 'You have successfully logged in.', 'success', 0, '2025-08-18 13:32:26'),
(52, 1, 'Logged Out', 'You have successfully logged out.', 'info', 0, '2025-08-18 13:33:49'),
(53, 2, 'Welcome Back!', 'You have successfully logged in.', 'success', 0, '2025-08-18 13:34:25'),
(54, 2, 'Logged Out', 'You have successfully logged out.', 'info', 0, '2025-08-18 23:56:27'),
(55, 2, 'Welcome Back!', 'You have successfully logged in.', 'success', 0, '2025-08-19 05:12:09'),
(56, 2, 'Welcome Back!', 'You have successfully logged in.', 'success', 0, '2025-08-19 12:41:05'),
(57, 2, 'Logged Out', 'You have successfully logged out.', 'info', 0, '2025-08-19 12:48:24'),
(58, 1, 'Welcome Back!', 'You have successfully logged in.', 'success', 0, '2025-08-19 12:48:35'),
(59, 1, 'Logged Out', 'You have successfully logged out.', 'info', 0, '2025-08-19 17:04:28'),
(60, 2, 'Welcome Back!', 'You have successfully logged in.', 'success', 0, '2025-08-19 17:04:38'),
(61, 1, 'Welcome Back!', 'You have successfully logged in.', 'success', 0, '2025-08-21 13:02:42'),
(62, 1, 'Welcome Back!', 'You have successfully logged in.', 'success', 0, '2025-08-21 13:16:47'),
(63, 2, 'Welcome Back!', 'You have successfully logged in.', 'success', 0, '2025-08-21 13:18:22'),
(64, 2, 'Logged Out', 'You have successfully logged out.', 'info', 0, '2025-08-21 13:19:07'),
(65, 1, 'Welcome Back!', 'You have successfully logged in.', 'success', 0, '2025-08-21 13:19:39'),
(66, 1, 'Welcome Back!', 'You have successfully logged in.', 'success', 0, '2025-08-21 13:20:43'),
(67, 1, 'Welcome Back!', 'You have successfully logged in.', 'success', 0, '2025-08-21 13:21:05'),
(68, 1, 'Logged Out', 'You have successfully logged out.', 'info', 0, '2025-08-21 13:21:32'),
(69, 1, 'Welcome Back!', 'You have successfully logged in.', 'success', 0, '2025-08-21 13:21:48'),
(70, 1, 'Logged Out', 'You have successfully logged out.', 'info', 0, '2025-08-21 13:22:24'),
(71, 1, 'Welcome Back!', 'You have successfully logged in.', 'success', 0, '2025-08-21 13:23:01'),
(72, 1, 'Logged Out', 'You have successfully logged out.', 'info', 0, '2025-08-21 13:26:22'),
(73, 2, 'Welcome Back!', 'You have successfully logged in.', 'success', 0, '2025-08-21 13:26:30'),
(74, 2, 'Logged Out', 'You have successfully logged out.', 'info', 0, '2025-08-21 13:39:19'),
(75, 1, 'Welcome Back!', 'You have successfully logged in.', 'success', 0, '2025-08-21 13:39:26'),
(76, 1, 'Welcome Back!', 'You have successfully logged in.', 'success', 0, '2025-08-21 14:16:45'),
(77, 1, 'Logged Out', 'You have successfully logged out.', 'info', 0, '2025-08-21 14:17:01'),
(78, 2, 'Welcome Back!', 'You have successfully logged in.', 'success', 0, '2025-08-21 14:17:20'),
(79, 2, 'Logged Out', 'You have successfully logged out.', 'info', 0, '2025-08-21 14:26:04'),
(80, 2, 'Welcome Back!', 'You have successfully logged in.', 'success', 0, '2025-08-22 06:14:14'),
(81, 2, 'Logged Out', 'You have successfully logged out.', 'info', 0, '2025-08-22 08:07:54'),
(82, 1, 'Welcome Back!', 'You have successfully logged in.', 'success', 0, '2025-08-22 08:08:43'),
(83, 2, 'Account Updated', 'Your account role has been updated by an administrator.', 'info', 0, '2025-08-22 08:13:15'),
(84, 1, 'Logged Out', 'You have successfully logged out.', 'info', 0, '2025-08-22 08:15:07'),
(85, 3, 'Welcome Back!', 'You have successfully logged in.', 'success', 0, '2025-08-22 08:15:15'),
(86, 1, 'Welcome Back!', 'You have successfully logged in.', 'success', 0, '2025-08-23 07:03:00'),
(87, 1, 'Logged Out', 'You have successfully logged out.', 'info', 0, '2025-08-23 07:03:40'),
(88, 2, 'Welcome Back!', 'You have successfully logged in.', 'success', 0, '2025-08-23 07:03:55'),
(89, 1, 'Welcome Back!', 'You have successfully logged in.', 'success', 0, '2025-08-23 07:12:44'),
(90, 1, 'Logged Out', 'You have successfully logged out.', 'info', 0, '2025-08-23 07:12:56'),
(91, 2, 'Welcome Back!', 'You have successfully logged in.', 'success', 0, '2025-08-23 07:14:16'),
(92, 2, 'Logged Out', 'You have successfully logged out.', 'info', 0, '2025-08-23 07:14:30'),
(93, 1, 'Welcome Back!', 'You have successfully logged in.', 'success', 0, '2025-08-23 07:14:55'),
(94, 2, 'Account Updated', 'Your account role has been updated by an administrator.', 'info', 0, '2025-08-23 07:15:19'),
(95, 1, 'Logged Out', 'You have successfully logged out.', 'info', 0, '2025-08-23 07:18:57'),
(96, 1, 'Welcome Back!', 'You have successfully logged in.', 'success', 0, '2025-08-23 07:19:09'),
(97, 1, 'Logged Out', 'You have successfully logged out.', 'info', 0, '2025-08-23 07:20:19'),
(98, 2, 'Welcome Back!', 'You have successfully logged in.', 'success', 0, '2025-08-23 07:20:26'),
(99, 2, 'Logged Out', 'You have successfully logged out.', 'info', 0, '2025-08-23 07:22:29'),
(100, 1, 'Welcome Back!', 'You have successfully logged in.', 'success', 0, '2025-08-23 07:22:36'),
(101, 1, 'Logged Out', 'You have successfully logged out.', 'info', 0, '2025-08-23 07:23:16'),
(102, 2, 'Welcome Back!', 'You have successfully logged in.', 'success', 0, '2025-08-23 07:23:28'),
(103, 3, 'Welcome Back!', 'You have successfully logged in.', 'success', 0, '2025-08-23 08:00:22'),
(104, 3, 'Logged Out', 'You have successfully logged out.', 'info', 0, '2025-08-23 08:05:01'),
(105, 1, 'Welcome Back!', 'You have successfully logged in.', 'success', 0, '2025-08-23 08:05:14'),
(106, 2, 'Account Updated', 'Your account role has been updated by an administrator.', 'info', 0, '2025-08-23 08:06:24'),
(107, 1, 'Logged Out', 'You have successfully logged out.', 'info', 0, '2025-08-23 08:11:25'),
(108, 1, 'Welcome Back!', 'You have successfully logged in.', 'success', 0, '2025-08-27 05:50:23'),
(109, 1, 'Logged Out', 'You have successfully logged out.', 'info', 0, '2025-08-27 05:52:43'),
(110, 2, 'Welcome Back!', 'You have successfully logged in.', 'success', 0, '2025-08-27 05:52:52'),
(111, 2, 'Logged Out', 'You have successfully logged out.', 'info', 0, '2025-08-27 05:53:03'),
(112, 1, 'Welcome Back!', 'You have successfully logged in.', 'success', 0, '2025-08-27 05:53:29'),
(113, 1, 'Logged Out', 'You have successfully logged out.', 'info', 0, '2025-08-27 05:56:15'),
(114, 1, 'Welcome Back!', 'You have successfully logged in.', 'success', 0, '2025-08-27 05:56:24'),
(115, 1, 'Logged Out', 'You have successfully logged out.', 'info', 0, '2025-08-27 05:57:15'),
(116, 4, 'Welcome Back!', 'You have successfully logged in.', 'success', 0, '2025-08-27 05:57:24'),
(117, 4, 'Logged Out', 'You have successfully logged out.', 'info', 0, '2025-08-27 06:00:30'),
(118, 2, 'Welcome Back!', 'You have successfully logged in.', 'success', 0, '2025-08-27 06:00:40'),
(119, 2, 'Logged Out', 'You have successfully logged out.', 'info', 0, '2025-08-27 06:14:16'),
(120, 2, 'Welcome Back!', 'You have successfully logged in.', 'success', 0, '2025-08-27 06:16:35'),
(121, 2, 'Logged Out', 'You have successfully logged out.', 'info', 0, '2025-08-27 06:21:19'),
(122, 2, 'Welcome Back!', 'You have successfully logged in.', 'success', 0, '2025-08-27 13:50:51'),
(123, 1, 'Welcome Back!', 'You have successfully logged in.', 'success', 0, '2025-09-08 16:27:11'),
(124, 1, 'Logged Out', 'You have successfully logged out.', 'info', 0, '2025-09-08 16:27:57'),
(125, 5, 'Welcome Back!', 'You have successfully logged in.', 'success', 0, '2025-09-08 16:37:48'),
(126, 5, 'Logged Out', 'You have successfully logged out.', 'info', 0, '2025-09-08 16:58:03'),
(127, 2, 'Welcome Back!', 'You have successfully logged in.', 'success', 0, '2025-09-08 16:58:11'),
(128, 2, 'Logged Out', 'You have successfully logged out.', 'info', 0, '2025-09-08 17:03:00'),
(129, 5, 'Welcome Back!', 'You have successfully logged in.', 'success', 0, '2025-09-08 17:06:35'),
(130, 5, 'Logged Out', 'You have successfully logged out.', 'info', 0, '2025-09-09 00:36:55'),
(131, 5, 'Welcome Back!', 'You have successfully logged in.', 'success', 0, '2025-09-09 00:39:58'),
(132, 5, 'Logged Out', 'You have successfully logged out.', 'info', 0, '2025-09-09 01:10:39'),
(133, 1, 'Welcome Back!', 'You have successfully logged in.', 'success', 0, '2025-09-09 01:10:54'),
(134, 1, 'Logged Out', 'You have successfully logged out.', 'info', 0, '2025-09-09 01:13:06'),
(135, 5, 'Welcome Back!', 'You have successfully logged in.', 'success', 0, '2025-09-09 01:13:21'),
(136, 5, 'Logged Out', 'You have successfully logged out.', 'info', 0, '2025-09-09 01:14:36'),
(137, 5, 'Welcome Back!', 'You have successfully logged in.', 'success', 0, '2025-09-09 01:14:43'),
(138, 5, 'Logged Out', 'You have successfully logged out.', 'info', 0, '2025-09-09 01:15:31'),
(139, 1, 'Welcome Back!', 'You have successfully logged in.', 'success', 0, '2025-09-09 01:15:37'),
(140, 1, 'Logged Out', 'You have successfully logged out.', 'info', 0, '2025-09-09 01:17:52'),
(141, 1, 'Welcome Back!', 'You have successfully logged in.', 'success', 0, '2025-09-09 01:29:09'),
(142, 1, 'Logged Out', 'You have successfully logged out.', 'info', 0, '2025-09-09 01:29:43'),
(143, 5, 'Welcome Back!', 'You have successfully logged in.', 'success', 0, '2025-09-09 01:29:49'),
(144, 5, 'Logged Out', 'You have successfully logged out.', 'info', 0, '2025-09-09 03:18:49'),
(145, 5, 'Welcome Back!', 'You have successfully logged in.', 'success', 0, '2025-09-09 03:19:17');

-- --------------------------------------------------------

--
-- Table structure for table `player_stats`
--

CREATE TABLE `player_stats` (
  `id` int(11) NOT NULL,
  `player_id` int(11) NOT NULL,
  `league_id` int(11) NOT NULL,
  `team_id` int(11) NOT NULL,
  `matches_played` int(11) DEFAULT 0,
  `goals` int(11) DEFAULT 0,
  `assists` int(11) DEFAULT 0,
  `yellow_cards` int(11) DEFAULT 0,
  `red_cards` int(11) DEFAULT 0,
  `minutes_played` int(11) DEFAULT 0,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `registration_requests`
--

CREATE TABLE `registration_requests` (
  `id` int(11) NOT NULL,
  `player_id` int(11) NOT NULL,
  `team_id` int(11) NOT NULL,
  `league_id` int(11) NOT NULL,
  `preferred_position` varchar(50) DEFAULT NULL,
  `message` text DEFAULT NULL,
  `status` enum('pending','approved','rejected') DEFAULT 'pending',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `processed_at` timestamp NULL DEFAULT NULL,
  `processed_by` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `sports`
--

CREATE TABLE `sports` (
  `id` int(11) NOT NULL,
  `name` varchar(50) NOT NULL,
  `description` text DEFAULT NULL,
  `max_players_per_team` int(11) DEFAULT 11,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `sports`
--

INSERT INTO `sports` (`id`, `name`, `description`, `max_players_per_team`, `created_at`) VALUES
(1, 'Football', 'Association Football (Soccer)', 11, '2025-08-09 03:22:05'),
(2, 'Basketball', 'Indoor Basketball', 5, '2025-08-09 03:22:05'),
(3, 'Volleyball', 'Indoor/Outdoor Volleyball', 6, '2025-08-09 03:22:05'),
(4, 'Tennis', 'Singles/Doubles Tennis', 2, '2025-08-09 03:22:05');

-- --------------------------------------------------------

--
-- Table structure for table `teams`
--

CREATE TABLE `teams` (
  `id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `league_id` int(11) NOT NULL,
  `owner_id` int(11) NOT NULL,
  `description` text DEFAULT NULL,
  `logo_url` varchar(255) DEFAULT NULL,
  `wins` int(11) DEFAULT 0,
  `losses` int(11) DEFAULT 0,
  `draws` int(11) DEFAULT 0,
  `points` int(11) DEFAULT 0,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `teams`
--

INSERT INTO `teams` (`id`, `name`, `league_id`, `owner_id`, `description`, `logo_url`, `wins`, `losses`, `draws`, `points`, `created_at`) VALUES
(1, 'Red', 1, 1, 'wqewqe', NULL, 0, 0, 0, 0, '2025-08-09 05:37:38'),
(2, 'wqewq', 2, 1, 'qwe', NULL, 0, 0, 0, 0, '2025-08-09 05:38:31'),
(4, 'zz', 2, 2, 'wewe', NULL, 0, 0, 0, 0, '2025-08-09 16:05:01'),
(5, 'xxx', 4, 2, 'xxx', NULL, 0, 0, 0, 0, '2025-08-13 03:59:07'),
(6, 'Team Black', 11, 2, 'champions', NULL, 0, 0, 0, 0, '2025-08-21 14:18:13'),
(7, 'sdasdsad', 11, 3, 'we4werr', NULL, 0, 0, 0, 0, '2025-08-23 08:03:34');

-- --------------------------------------------------------

--
-- Table structure for table `team_members`
--

CREATE TABLE `team_members` (
  `id` int(11) NOT NULL,
  `team_id` int(11) NOT NULL,
  `player_id` int(11) NOT NULL,
  `position` varchar(50) DEFAULT NULL,
  `jersey_number` int(11) DEFAULT NULL,
  `joined_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `status` enum('active','inactive','suspended') DEFAULT 'active'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `team_members`
--

INSERT INTO `team_members` (`id`, `team_id`, `player_id`, `position`, `jersey_number`, `joined_at`, `status`) VALUES
(1, 1, 1, 'Captain', NULL, '2025-08-09 05:37:38', 'active'),
(2, 2, 1, 'Captain', NULL, '2025-08-09 05:38:31', 'active'),
(4, 4, 2, 'Captain', NULL, '2025-08-09 16:05:01', 'active'),
(5, 5, 2, 'Captain', NULL, '2025-08-13 03:59:07', 'active'),
(6, 6, 2, 'Captain', NULL, '2025-08-21 14:18:13', 'active'),
(7, 7, 3, 'Captain', NULL, '2025-08-23 08:03:34', 'active');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `username` varchar(50) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password` varchar(255) NOT NULL,
  `first_name` varchar(50) NOT NULL,
  `last_name` varchar(50) NOT NULL,
  `phone` varchar(20) DEFAULT NULL,
  `role` enum('player','team_owner','admin') DEFAULT 'player',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `status` varchar(20) NOT NULL DEFAULT 'active'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `username`, `email`, `password`, `first_name`, `last_name`, `phone`, `role`, `created_at`, `updated_at`, `status`) VALUES
(1, 'admin', 'admin@sportsleague.com', '$2y$10$QRMEydO4LLStL5/amQ1sTexmcZMvj1.sGxBa6CuKdCiJil7buEMyG', 'System', 'Administrator', NULL, 'admin', '2025-08-09 03:22:05', '2025-09-09 01:29:43', 'active'),
(2, 'vanz', 'vanzy@gmail.com', '$2y$10$pCBh51c8u.ZTeXMKYMfpnexqFn2jBcGpsUe/j/Mldeos1WVMDgW/O', 'John', 'Mark', '112212', 'team_owner', '2025-08-09 15:54:36', '2025-09-08 17:03:00', 'active'),
(3, 'james', 'james@gmail.com', '$2y$10$gRok6CiY8I/O8hEzJX1aHueAcV6zRgVLFBIahBJkI14IS/spPiidy', 'James', 'Lover', '09452560280', 'player', '2025-08-22 08:12:15', '2025-08-23 08:05:01', 'active'),
(4, 'leemar', 'leemar@gmail.com', '$2y$10$xWyt/kdcivlh1QtuCH5.L.X6rOq.Mept2M/OHEG27KdH72BpJrzia', 'Leemar', 'Baril', '09452560280', 'player', '2025-08-27 05:57:13', '2025-08-27 06:00:30', 'active'),
(5, 'kevs', 'kevs@gmail.com', '$2y$10$Gbht9fq1jYVkjJd3l9N14eN6AbwxNeYbULcKxzowT.MHXzL9kNRaO', 'Kevin', 'John', '093248699580', 'player', '2025-09-08 16:37:31', '2025-09-09 03:19:17', 'active');

-- --------------------------------------------------------

--
-- Table structure for table `venues`
--

CREATE TABLE `venues` (
  `id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `address` text NOT NULL,
  `capacity` int(11) DEFAULT NULL,
  `facilities` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `venues`
--

INSERT INTO `venues` (`id`, `name`, `address`, `capacity`, `facilities`, `created_at`) VALUES
(1, 'Central Sports Complex', '123 Sports Ave, City Center', 5000, NULL, '2025-08-09 03:22:05'),
(2, 'Community Field A', '456 Park St, Downtown', 1000, NULL, '2025-08-09 03:22:05'),
(3, 'Indoor Arena', '789 Arena Blvd, Sports District', 3000, NULL, '2025-08-09 03:22:05'),
(4, 'zzz', 'asdasdasd', 500, 'asd', '2025-08-09 05:45:24');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `leagues`
--
ALTER TABLE `leagues`
  ADD PRIMARY KEY (`id`),
  ADD KEY `sport_id` (`sport_id`),
  ADD KEY `created_by` (`created_by`);

--
-- Indexes for table `matches`
--
ALTER TABLE `matches`
  ADD PRIMARY KEY (`id`),
  ADD KEY `league_id` (`league_id`),
  ADD KEY `home_team_id` (`home_team_id`),
  ADD KEY `away_team_id` (`away_team_id`),
  ADD KEY `venue_id` (`venue_id`);

--
-- Indexes for table `notifications`
--
ALTER TABLE `notifications`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`);

--
-- Indexes for table `player_stats`
--
ALTER TABLE `player_stats`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `unique_player_league` (`player_id`,`league_id`),
  ADD KEY `league_id` (`league_id`),
  ADD KEY `team_id` (`team_id`);

--
-- Indexes for table `registration_requests`
--
ALTER TABLE `registration_requests`
  ADD PRIMARY KEY (`id`),
  ADD KEY `player_id` (`player_id`),
  ADD KEY `team_id` (`team_id`),
  ADD KEY `league_id` (`league_id`),
  ADD KEY `processed_by` (`processed_by`);

--
-- Indexes for table `sports`
--
ALTER TABLE `sports`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `teams`
--
ALTER TABLE `teams`
  ADD PRIMARY KEY (`id`),
  ADD KEY `league_id` (`league_id`),
  ADD KEY `owner_id` (`owner_id`);

--
-- Indexes for table `team_members`
--
ALTER TABLE `team_members`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `unique_team_player` (`team_id`,`player_id`),
  ADD KEY `player_id` (`player_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `username` (`username`),
  ADD UNIQUE KEY `email` (`email`);

--
-- Indexes for table `venues`
--
ALTER TABLE `venues`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `leagues`
--
ALTER TABLE `leagues`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT for table `matches`
--
ALTER TABLE `matches`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `notifications`
--
ALTER TABLE `notifications`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=146;

--
-- AUTO_INCREMENT for table `player_stats`
--
ALTER TABLE `player_stats`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `registration_requests`
--
ALTER TABLE `registration_requests`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `sports`
--
ALTER TABLE `sports`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `teams`
--
ALTER TABLE `teams`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `team_members`
--
ALTER TABLE `team_members`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `venues`
--
ALTER TABLE `venues`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `leagues`
--
ALTER TABLE `leagues`
  ADD CONSTRAINT `leagues_ibfk_1` FOREIGN KEY (`sport_id`) REFERENCES `sports` (`id`),
  ADD CONSTRAINT `leagues_ibfk_2` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`);

--
-- Constraints for table `matches`
--
ALTER TABLE `matches`
  ADD CONSTRAINT `matches_ibfk_1` FOREIGN KEY (`league_id`) REFERENCES `leagues` (`id`),
  ADD CONSTRAINT `matches_ibfk_2` FOREIGN KEY (`home_team_id`) REFERENCES `teams` (`id`),
  ADD CONSTRAINT `matches_ibfk_3` FOREIGN KEY (`away_team_id`) REFERENCES `teams` (`id`),
  ADD CONSTRAINT `matches_ibfk_4` FOREIGN KEY (`venue_id`) REFERENCES `venues` (`id`);

--
-- Constraints for table `notifications`
--
ALTER TABLE `notifications`
  ADD CONSTRAINT `notifications_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`);

--
-- Constraints for table `player_stats`
--
ALTER TABLE `player_stats`
  ADD CONSTRAINT `player_stats_ibfk_1` FOREIGN KEY (`player_id`) REFERENCES `users` (`id`),
  ADD CONSTRAINT `player_stats_ibfk_2` FOREIGN KEY (`league_id`) REFERENCES `leagues` (`id`),
  ADD CONSTRAINT `player_stats_ibfk_3` FOREIGN KEY (`team_id`) REFERENCES `teams` (`id`);

--
-- Constraints for table `registration_requests`
--
ALTER TABLE `registration_requests`
  ADD CONSTRAINT `registration_requests_ibfk_1` FOREIGN KEY (`player_id`) REFERENCES `users` (`id`),
  ADD CONSTRAINT `registration_requests_ibfk_2` FOREIGN KEY (`team_id`) REFERENCES `teams` (`id`),
  ADD CONSTRAINT `registration_requests_ibfk_3` FOREIGN KEY (`league_id`) REFERENCES `leagues` (`id`),
  ADD CONSTRAINT `registration_requests_ibfk_4` FOREIGN KEY (`processed_by`) REFERENCES `users` (`id`);

--
-- Constraints for table `teams`
--
ALTER TABLE `teams`
  ADD CONSTRAINT `teams_ibfk_1` FOREIGN KEY (`league_id`) REFERENCES `leagues` (`id`),
  ADD CONSTRAINT `teams_ibfk_2` FOREIGN KEY (`owner_id`) REFERENCES `users` (`id`);

--
-- Constraints for table `team_members`
--
ALTER TABLE `team_members`
  ADD CONSTRAINT `team_members_ibfk_1` FOREIGN KEY (`team_id`) REFERENCES `teams` (`id`),
  ADD CONSTRAINT `team_members_ibfk_2` FOREIGN KEY (`player_id`) REFERENCES `users` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
