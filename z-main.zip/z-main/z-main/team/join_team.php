
<?php
// team/join_team.php - Join Existing Teams System
require_once '../config/database.php';
requireLogin();

$database = new Database();
$db = $database->connect();
$current_user = getCurrentUser();

// Handle join request submission
if ($_POST) {
    if (isset($_POST['send_request'])) {
        $team_id = $_POST['team_id'];
        $preferred_position = trim($_POST['preferred_position']);
        $message = trim($_POST['message']);

        // Check if user already has a pending request for this team
        $check_query = "SELECT id FROM registration_requests
                        WHERE player_id = :player_id AND team_id = :team_id AND status = 'pending'";
        $check_stmt = $db->prepare($check_query);
        $check_stmt->bindParam(':player_id', $current_user['id']);
        $check_stmt->bindParam(':team_id', $team_id);
        $check_stmt->execute();

        if ($check_stmt->rowCount() > 0) {
            showMessage("You already have a pending request for this team!", "error");
        } else {
            // Check if user is already a member of this team
            $member_check = "SELECT id FROM team_members
                            WHERE player_id = :player_id AND team_id = :team_id AND status = 'active'";
            $member_stmt = $db->prepare($member_check);
            $member_stmt->bindParam(':player_id', $current_user['id']);
            $member_stmt->bindParam(':team_id', $team_id);
            $member_stmt->execute();

            if ($member_stmt->rowCount() > 0) {
                showMessage("You are already a member of this team!", "error");
            } else {
                // Get league_id for the team
                $team_query = "SELECT league_id FROM teams WHERE id = :team_id";
                $team_stmt = $db->prepare($team_query);
                $team_stmt->bindParam(':team_id', $team_id);
                $team_stmt->execute();
                $team = $team_stmt->fetch(PDO::FETCH_ASSOC);

                // Insert join request
                $insert_query = "INSERT INTO registration_requests (player_id, team_id, league_id, preferred_position, message)
                                VALUES (:player_id, :team_id, :league_id, :preferred_position, :message)";
                $insert_stmt = $db->prepare($insert_query);
                $insert_stmt->bindParam(':player_id', $current_user['id']);
                $insert_stmt->bindParam(':team_id', $team_id);
                $insert_stmt->bindParam(':league_id', $team['league_id']);
                $insert_stmt->bindParam(':preferred_position', $preferred_position);
                $insert_stmt->bindParam(':message', $message);

                if ($insert_stmt->execute()) {
                    // Create notification for team owner
                    $owner_query = "SELECT owner_id FROM teams WHERE id = :team_id";
                    $owner_stmt = $db->prepare($owner_query);
                    $owner_stmt->bindParam(':team_id', $team_id);
                    $owner_stmt->execute();
                    $owner = $owner_stmt->fetch(PDO::FETCH_ASSOC);

                    if ($owner) {
                        $notification_query = "INSERT INTO notifications (user_id, title, message, type)
                                              VALUES (:user_id, 'New Team Join Request',
                                              :message, 'info')";
                        $notification_stmt = $db->prepare($notification_query);
                        $notification_stmt->bindParam(':user_id', $owner['owner_id']);
                        $notif_message = $current_user['first_name'] . ' ' . $current_user['last_name'] . ' wants to join your team!';
                        $notification_stmt->bindParam(':message', $notif_message);
                        $notification_stmt->execute();
                    }

                    showMessage("Join request sent successfully! The team owner will review your request.", "success");
                } else {
                    showMessage("Failed to send join request!", "error");
                }
            }
        }
    }

    if (isset($_POST['cancel_request'])) {
        $request_id = $_POST['request_id'];

        // Delete the pending request
        $cancel_query = "DELETE FROM registration_requests WHERE id = :id AND player_id = :player_id";
        $cancel_stmt = $db->prepare($cancel_query);
        $cancel_stmt->bindParam(':id', $request_id);
        $cancel_stmt->bindParam(':player_id', $current_user['id']);

        if ($cancel_stmt->execute()) {
            showMessage("Join request cancelled successfully!", "success");
        } else {
            showMessage("Failed to cancel request!", "error");
        }
    }
}

// Get filter parameters
$league_filter = $_GET['league'] ?? '';
$sport_filter = $_GET['sport'] ?? '';
$search = $_GET['search'] ?? '';
$league_id = $_GET['league_id'] ?? ''; // If coming from a specific league

// Build query conditions
$where_conditions = ["l.status IN ('open', 'active')"];
$params = [];

if ($search) {
    $where_conditions[] = "(t.name LIKE :search OR t.description LIKE :search OR u.first_name LIKE :search OR u.last_name LIKE :search)";
    $params[':search'] = "%$search%";
}

if ($league_filter) {
    $where_conditions[] = "t.league_id = :league_id";
    $params[':league_id'] = $league_filter;
} elseif ($league_id) {
    $where_conditions[] = "t.league_id = :league_id";
    $params[':league_id'] = $league_id;
}

if ($sport_filter) {
    $where_conditions[] = "s.id = :sport_id";
    $params[':sport_id'] = $sport_filter;
}

// Exclude teams user already owns or is member of
$where_conditions[] = "t.owner_id != :user_id";
$where_conditions[] = "t.id NOT IN (
    SELECT team_id FROM team_members WHERE player_id = :user_id AND status = 'active'
)";
$params[':user_id'] = $current_user['id'];

$where_clause = "WHERE " . implode(" AND ", $where_conditions);

// Get available teams
$teams_query = "SELECT t.*, l.name as league_name, l.season, l.status as league_status,
                       l.registration_deadline, l.max_teams,
                       s.name as sport_name, s.max_players_per_team,
                       u.first_name as owner_first_name, u.last_name as owner_last_name, u.username as owner_username,
                       (SELECT COUNT(*) FROM team_members WHERE team_id = t.id AND status = 'active') as member_count,
                       (SELECT COUNT(*) FROM registration_requests WHERE team_id = t.id AND status = 'pending') as pending_requests,
                       (SELECT COUNT(*) FROM registration_requests WHERE team_id = t.id AND player_id = :user_id AND status = 'pending') as user_has_pending
                FROM teams t
                JOIN leagues l ON t.league_id = l.id
                JOIN sports s ON l.sport_id = s.id
                JOIN users u ON t.owner_id = u.id
                $where_clause
                ORDER BY l.status DESC, t.created_at DESC";

$teams_stmt = $db->prepare($teams_query);
foreach ($params as $key => $value) {
    $teams_stmt->bindValue($key, $value);
}
$teams_stmt->execute();
$available_teams = $teams_stmt->fetchAll(PDO::FETCH_ASSOC);

// Get user's pending requests for display
$pending_requests_query = "SELECT rr.*, t.name as team_name, l.name as league_name, l.season, s.name as sport_name
                           FROM registration_requests rr
                           JOIN teams t ON rr.team_id = t.id
                           JOIN leagues l ON rr.league_id = l.id
                           JOIN sports s ON l.sport_id = s.id
                           WHERE rr.player_id = :user_id AND rr.status = 'pending'
                           ORDER BY rr.created_at DESC";
$pending_requests_stmt = $db->prepare($pending_requests_query);
$pending_requests_stmt->bindParam(':user_id', $current_user['id']);
$pending_requests_stmt->execute();
$user_pending_requests = $pending_requests_stmt->fetchAll(PDO::FETCH_ASSOC);

// Get leagues and sports for filters
$leagues_query = "SELECT l.*, s.name as sport_name FROM leagues l
                  JOIN sports s ON l.sport_id = s.id
                  WHERE l.status IN ('open', 'active')
                  ORDER BY l.name";
$leagues_stmt = $db->prepare($leagues_query);
$leagues_stmt->execute();
$leagues = $leagues_stmt->fetchAll(PDO::FETCH_ASSOC);

$sports_query = "SELECT * FROM sports ORDER BY name";
$sports_stmt = $db->prepare($sports_query);
$sports_stmt->execute();
$sports = $sports_stmt->fetchAll(PDO::FETCH_ASSOC);

// Get user's current teams count for statistics
$user_teams_count = 0;
$user_teams_query = "SELECT COUNT(*) FROM team_members WHERE player_id = :user_id AND status = 'active'";
$user_teams_stmt = $db->prepare($user_teams_query);
$user_teams_stmt->bindParam(':user_id', $current_user['id']);
$user_teams_stmt->execute();
$user_teams_count = $user_teams_stmt->fetchColumn();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Join a Team - Sports League Management</title>
    <link rel="stylesheet" href="style.css">

</head>

<body>
    <!-- Header -->
    <div class="header">
        <div class="header-content">
            <h1>👥 Join a Team</h1>
            <p>Find the perfect team to showcase your skills and passion</p>
        </div>
    </div>

    <!-- Breadcrumb -->
    <div class="nav-breadcrumb">
        <div class="breadcrumb">
            <a href="../dashboard.php">Dashboard</a>
            <span>›</span>
            <a href="my_teams.php">My Teams</a>
            <span>›</span>
            <span>Join Team</span>
        </div>
    </div>

    <div class="container">
        <!-- Display messages -->
        <?php displayMessage(); ?>

        <!-- User Info Section -->
        <div class="user-info">
            <h3 style="margin-bottom: 1rem; color: #fff;">
                👋 Welcome, <?php echo htmlspecialchars($current_user['first_name']); ?>!
            </h3>
            <p style="color: rgba(255,255,255,0.9); margin-bottom: 1rem;">
                Ready to join a team? Browse available teams below and send join requests to team owners.
            </p>

            <div class="user-stats">
                <div class="stat-item">
                    <div class="stat-number"><?php echo $user_teams_count; ?></div>
                    <div class="stat-label">Current Teams</div>
                </div>
                <div class="stat-item">
                    <div class="stat-number"><?php echo count($user_pending_requests); ?></div>
                    <div class="stat-label">Pending Requests</div>
                </div>
                <div class="stat-item">
                    <div class="stat-number"><?php echo count($available_teams); ?></div>
                    <div class="stat-label">Available Teams</div>
                </div>
            </div>
        </div>

        <!-- Tips Section -->
        <div class="tips-section">
            <h3 style="margin-bottom: 1rem;">💡 Tips for Joining Teams</h3>
            <div class="tips-grid">
                <div class="tip-item">
                    <div class="tip-icon">🎯</div>
                    <h4>Be Specific</h4>
                    <p>Mention your preferred position and playing experience in your message.</p>
                </div>
                <div class="tip-item">
                    <div class="tip-icon">🤝</div>
                    <h4>Be Respectful</h4>
                    <p>Write a polite message explaining why you want to join their team.</p>
                </div>
                <div class="tip-item">
                    <div class="tip-icon">⚡</div>
                    <h4>Act Fast</h4>
                    <p>Popular teams fill up quickly, so send your requests promptly.</p>
                </div>
                <div class="tip-item">
                    <div class="tip-icon">📈</div>
                    <h4>Show Commitment</h4>
                    <p>Demonstrate your dedication to the sport and team success.</p>
                </div>
            </div>
        </div>

        <!-- Pending Requests Section -->
        <?php if (count($user_pending_requests) > 0): ?>
        <div class="pending-requests-section">
            <h3 style="margin-bottom: 1rem; color: #333;">⏳ Your Pending Requests (<?php echo count($user_pending_requests); ?>)</h3>

            <?php foreach ($user_pending_requests as $request): ?>
            <div class="request-card">
                <div class="request-header">
                    <div class="request-team">
                        <?php echo htmlspecialchars($request['team_name']); ?>
                        <small>(<?php echo htmlspecialchars($request['league_name']); ?> - <?php echo htmlspecialchars($request['season']); ?>)</small>
                    </div>
                    <form method="post" style="margin:0;">
                        <input type="hidden" name="request_id" value="<?php echo $request['id']; ?>">
                        <button type="submit" name="cancel_request" class="btn btn-danger btn-sm"
                                onclick="return confirm('Are you sure you want to cancel this request?')">Cancel</button>
                    </form>
                </div>
                <div class="request-details" style="margin-top: 0.5rem; font-size: 0.9rem; color: #555;">
                    <strong>Position:</strong> <?php echo htmlspecialchars($request['preferred_position']); ?><br>
                    <strong>Message:</strong> <?php echo htmlspecialchars($request['message']); ?><br>
                    <strong>Requested on:</strong> <?php echo date('M j, Y g:i A', strtotime($request['created_at'])); ?>
                </div>
            </div>
            <?php endforeach; ?>
        </div>
        <?php endif; ?>

        <!-- Filters Section -->
        <div class="filters-section">
            <h3 style="margin-bottom: 1rem;">🔍 Search & Filter Teams</h3>
            <form method="get" class="filters-form">
                <div class="form-group" style="margin-bottom: 0;">
                    <label for="search">Search Teams</label>
                    <input type="text" id="search" name="search" placeholder="Team name, description, or owner..."
                           value="<?php echo htmlspecialchars($search); ?>">
                </div>
                <div class="form-group" style="margin-bottom: 0;">
                    <label for="league">League</label>
                    <select id="league" name="league">
                        <option value="">All Leagues</option>
                        <?php foreach ($leagues as $league): ?>
                        <option value="<?php echo $league['id']; ?>" <?php echo ($league_filter == $league['id']) ? 'selected' : ''; ?>>
                            <?php echo htmlspecialchars($league['name']); ?> (<?php echo htmlspecialchars($league['sport_name']); ?>)
                        </option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="form-group" style="margin-bottom: 0;">
                    <label for="sport">Sport</label>
                    <select id="sport" name="sport">
                        <option value="">All Sports</option>
                        <?php foreach ($sports as $sport): ?>
                        <option value="<?php echo $sport['id']; ?>" <?php echo ($sport_filter == $sport['id']) ? 'selected' : ''; ?>>
                            <?php echo htmlspecialchars($sport['name']); ?>
                        </option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="form-group" style="margin-bottom: 0;">
                    <button type="submit" class="btn btn-primary">Filter</button>
                    <a href="join_team.php" class="btn btn-secondary" style="margin-left: 0.5rem;">Clear</a>
                </div>
            </form>
        </div>

        <!-- Available Teams Section -->
        <div class="teams-section">
            <h3 style="margin-bottom: 1rem;">⚽ Available Teams (<?php echo count($available_teams); ?>)</h3>

            <?php if (count($available_teams) > 0): ?>
            <div class="teams-grid">
                <?php foreach ($available_teams as $team): ?>
                <div class="team-card">
                    <?php
                    // Determine team status
                    $is_full = $team['member_count'] >= $team['max_players_per_team'];
                    $has_pending = $team['user_has_pending'] > 0;
                    $deadline_passed = strtotime($team['registration_deadline']) < time();
                    ?>

                    <div class="team-header">
                        <div>
                            <h4 class="team-name"><?php echo htmlspecialchars($team['name']); ?></h4>
                            <div class="team-league">
                                <?php echo htmlspecialchars($team['league_name']); ?> - <?php echo htmlspecialchars($team['season']); ?>
                            </div>
                        </div>
                        <div class="team-sport">
                            <?php echo htmlspecialchars($team['sport_name']); ?>
                        </div>
                    </div>

                    <?php if ($team['description']): ?>
                    <div class="team-description">
                        <?php echo htmlspecialchars(substr($team['description'], 0, 150)); ?>
                        <?php if (strlen($team['description']) > 150): ?>...<?php endif; ?>
                    </div>
                    <?php endif; ?>

                    <div class="team-stats">
                        <div class="team-stat">
                            <div class="team-stat-number"><?php echo $team['member_count']; ?>/<?php echo $team['max_players_per_team']; ?></div>
                            <div class="team-stat-label">Players</div>
                        </div>
                        <div class="team-stat">
                            <div class="team-stat-number"><?php echo $team['pending_requests']; ?></div>
                            <div class="team-stat-label">Pending</div>
                        </div>
                        <div class="team-stat">
                            <div class="team-stat-number">
                                <?php echo date('M j', strtotime($team['registration_deadline'])); ?>
                            </div>
                            <div class="team-stat-label">Deadline</div>
                        </div>
                    </div>

                    <div class="team-owner">
                        <strong>Owner:</strong> <?php echo htmlspecialchars($team['owner_first_name'] . ' ' . $team['owner_last_name']); ?>
                        <small>(@<?php echo htmlspecialchars($team['owner_username']); ?>)</small>
                    </div>

                    <?php if ($has_pending): ?>
                        <button class="join-btn" disabled>
                            Request Pending
                        </button>
                    <?php elseif ($is_full): ?>
                        <button class="join-btn" disabled>
                            Team Full
                        </button>
                    <?php elseif ($deadline_passed): ?>
                        <button class="join-btn" disabled>
                            Registration Closed
                        </button>
                    <?php else: ?>
                        <button class="join-btn" onclick="openJoinModal(
                            <?php echo $team['id']; ?>,
                            '<?php echo addslashes(htmlspecialchars($team['name'])); ?>',
                            '<?php echo addslashes(htmlspecialchars($team['league_name'])); ?>',
                            '<?php echo addslashes(htmlspecialchars($team['sport_name'])); ?>'
                        )">
                            Send Join Request
                        </button>
                    <?php endif; ?>
                </div>
                <?php endforeach; ?>
            </div>
            <?php else: ?>
            <div class="empty-state">
                <div class="empty-state-icon">🔍</div>
                <h3>No Teams Found</h3>
                <p>
                    <?php if ($search || $league_filter || $sport_filter): ?>
                        No teams match your search criteria. Try adjusting your filters or <a href="join_team.php">clear all filters</a>.
                    <?php else: ?>
                        There are no teams available for you to join at the moment. Check back later or <a href="create_team.php">create your own team</a>!
                    <?php endif; ?>
                </p>
            </div>
            <?php endif; ?>
        </div>
    </div>

    <!-- Join Request Modal -->
    <div id="joinModal" class="modal">
        <div class="modal-content">
            <span class="close" onclick="closeJoinModal()">&times;</span>
            <h3 style="margin-bottom: 1.5rem;">📝 Send Join Request</h3>

            <div id="teamInfo" style="background: #f8f9fa; padding: 1rem; border-radius: 6px; margin-bottom: 1.5rem;">
                <!-- Team info will be populated by JavaScript -->
            </div>

            <form method="post" id="joinForm">
                <input type="hidden" id="team_id" name="team_id" value="">

                <div class="form-group">
                    <label for="preferred_position">Preferred Position *</label>
                    <input type="text" id="preferred_position" name="preferred_position"
                           placeholder="e.g. Forward, Midfielder, Goalkeeper..." required>
                    <small style="color: #666; font-size: 0.85rem;">
                        Specify the position you prefer to play
                    </small>
                </div>

                <div class="form-group">
                    <label for="message">Message to Team Owner *</label>
                    <textarea id="message" name="message" placeholder="Tell the team owner about yourself, your experience, and why you want to join their team..." required></textarea>
                    <small style="color: #666; font-size: 0.85rem;">
                        Include your playing experience, availability, and what you can bring to the team
                    </small>
                </div>

                <div style="display: flex; gap: 1rem; justify-content: flex-end; margin-top: 2rem;">
                    <button type="button" onclick="closeJoinModal()" class="btn btn-secondary">
                        Cancel
                    </button>
                    <button type="submit" name="send_request" class="btn btn-primary">
                        Send Request
                    </button>
                </div>
            </form>
        </div>
    </div>

    <script>
        // Modal functionality
        function openJoinModal(teamId, teamName, leagueName, sportName) {
            document.getElementById('team_id').value = teamId;
            document.getElementById('teamInfo').innerHTML = `
                <strong>Team:</strong> ${teamName}<br>
                <strong>League:</strong> ${leagueName}<br>
                <strong>Sport:</strong> ${sportName}
            `;
            document.getElementById('joinModal').style.display = 'block';
            document.body.style.overflow = 'hidden'; // Prevent background scrolling
        }

        function closeJoinModal() {
            document.getElementById('joinModal').style.display = 'none';
            document.body.style.overflow = 'auto'; // Restore scrolling
            document.getElementById('joinForm').reset();
        }

        // Close modal when clicking outside
        window.onclick = function(event) {
            const modal = document.getElementById('joinModal');
            if (event.target == modal) {
                closeJoinModal();
            }
        }

        // Close modal with Escape key
        document.addEventListener('keydown', function(event) {
            if (event.key === 'Escape') {
                closeJoinModal();
            }
        });

        // Form validation
        document.getElementById('joinForm').addEventListener('submit', function(e) {
            const position = document.getElementById('preferred_position').value.trim();
            const message = document.getElementById('message').value.trim();

            if (!position) {
                alert('Please enter your preferred position.');
                e.preventDefault();
                return;
            }

            if (message.length < 10) {
                alert('Please provide a more detailed message (at least 10 characters).');
                e.preventDefault();
                return;
            }

            if (message.length > 500) {
                alert('Message is too long. Please keep it under 500 characters.');
                e.preventDefault();
                return;
            }
        });

        // Auto-hide success/error messages after 5 seconds
        document.addEventListener('DOMContentLoaded', function() {
            const alerts = document.querySelectorAll('.alert');
            alerts.forEach(function(alert) {
                setTimeout(function() {
                    alert.style.transition = 'opacity 0.5s ease';
                    alert.style.opacity = '0';
                    setTimeout(function() {
                        alert.remove();
                    }, 500);
                }, 5000);
            });
        });

        // Search functionality enhancement
        const searchInput = document.getElementById('search');
        if (searchInput) {
            let searchTimeout;
            searchInput.addEventListener('input', function() {
                clearTimeout(searchTimeout);
                searchTimeout = setTimeout(function() {
                    // Auto-submit form after user stops typing for 1 second
                    if (searchInput.value.length > 2 || searchInput.value.length === 0) {
                        searchInput.closest('form').submit();
                    }
                }, 1000);
            });
        }

        // Enhanced team card interactions
        document.querySelectorAll('.team-card').forEach(function(card) {
            card.addEventListener('mouseenter', function() {
                this.style.transform = 'translateY(-4px)';
            });

            card.addEventListener('mouseleave', function() {
                this.style.transform = 'translateY(-2px)';
            });
        });

        // Confirmation for cancel requests
        document.querySelectorAll('button[name="cancel_request"]').forEach(function(button) {
            button.addEventListener('click', function(e) {
                if (!confirm('Are you sure you want to cancel this join request?')) {
                    e.preventDefault();
                }
            });
        });
    </script>
