<?php
// team/manage_team.php - Complete Team Management System
require_once '../config/database.php';
requireLogin();

$team_id = $_GET['id'] ?? null;
if (!$team_id) {
    showMessage("Team ID required!", "error");
    redirect('../dashboard.php');
}

$database = new Database();
$db = $database->connect();
$current_user = getCurrentUser();

// Get team details with comprehensive information
$team_query = "SELECT t.*, l.name as league_name, l.season, l.status as league_status, l.id as league_id,
                      l.registration_deadline, l.start_date as league_start, l.end_date as league_end,
                      s.name as sport_name, s.max_players_per_team,
                      u.first_name as owner_first_name, u.last_name as owner_last_name, u.username as owner_username,
                      (SELECT COUNT(*) FROM team_members WHERE team_id = t.id AND status = 'active') as member_count,
                      (SELECT COUNT(*) FROM matches WHERE (home_team_id = t.id OR away_team_id = t.id) AND status = 'scheduled' AND match_date >= NOW()) as upcoming_matches,
                      (SELECT COUNT(*) FROM matches WHERE (home_team_id = t.id OR away_team_id = t.id) AND status = 'completed') as completed_matches,
                      (SELECT COUNT(*) FROM registration_requests WHERE team_id = t.id AND status = 'pending') as pending_requests
               FROM teams t
               JOIN leagues l ON t.league_id = l.id
               JOIN sports s ON l.sport_id = s.id
               JOIN users u ON t.owner_id = u.id
               WHERE t.id = :id";
$team_stmt = $db->prepare($team_query);
$team_stmt->bindParam(':id', $team_id);
$team_stmt->execute();
$team = $team_stmt->fetch(PDO::FETCH_ASSOC);

if (!$team) {
    showMessage("Team not found!", "error");
    redirect('../dashboard.php');
}

// Check if user has permission to manage this team
$can_manage = ($current_user['role'] == 'admin' || $current_user['id'] == $team['owner_id']);
$is_member = false;

if (!$can_manage) {
    // Check if user is a team member
    $member_check = "SELECT * FROM team_members WHERE team_id = :team_id AND player_id = :player_id AND status = 'active'";
    $member_stmt = $db->prepare($member_check);
    $member_stmt->bindParam(':team_id', $team_id);
    $member_stmt->bindParam(':player_id', $current_user['id']);
    $member_stmt->execute();
    $member_info = $member_stmt->fetch(PDO::FETCH_ASSOC);

    if (!$member_info) {
        showMessage("Access denied! You are not a member of this team.", "error");
        redirect('../dashboard.php');
    }
    $is_member = true;
}

// Handle various team management actions
if ($_POST && $can_manage) {
    if (isset($_POST['update_team'])) {
        $name = trim($_POST['name']);
        $description = trim($_POST['description']);

        $update_query = "UPDATE teams SET name = :name, description = :description WHERE id = :id";
        $update_stmt = $db->prepare($update_query);
        $update_stmt->bindParam(':name', $name);
        $update_stmt->bindParam(':description', $description);
        $update_stmt->bindParam(':id', $team_id);

        if ($update_stmt->execute()) {
            showMessage("Team information updated successfully!", "success");
            // Refresh team data
            $team_stmt->execute();
            $team = $team_stmt->fetch(PDO::FETCH_ASSOC);
        } else {
            showMessage("Failed to update team information!", "error");
        }
    }

    elseif (isset($_POST['process_request'])) {
        $request_id = $_POST['request_id'];
        $action = $_POST['request_action']; // 'approve' or 'reject'

        // Get request details
        $request_query = "SELECT rr.*, u.first_name, u.last_name FROM registration_requests rr
                         JOIN users u ON rr.player_id = u.id
                         WHERE rr.id = :id AND rr.team_id = :team_id AND rr.status = 'pending'";
        $request_stmt = $db->prepare($request_query);
        $request_stmt->bindParam(':id', $request_id);
        $request_stmt->bindParam(':team_id', $team_id);
        $request_stmt->execute();
        $request = $request_stmt->fetch(PDO::FETCH_ASSOC);

        if ($request) {
            if ($action == 'approve') {
                // Check team capacity
                if ($team['member_count'] >= $team['max_players_per_team']) {
                    showMessage("Cannot approve - team is at maximum capacity!", "error");
                } else {
                    // Add player to team
                    $add_member_query = "INSERT INTO team_members (team_id, player_id, position, joined_at)
                                        VALUES (:team_id, :player_id, :position, NOW())";
                    $add_member_stmt = $db->prepare($add_member_query);
                    $add_member_stmt->bindParam(':team_id', $team_id);
                    $add_member_stmt->bindParam(':player_id', $request['player_id']);
                    $add_member_stmt->bindParam(':position', $request['preferred_position']);

                    if ($add_member_stmt->execute()) {
                        // Update request status
                        $update_request = "UPDATE registration_requests SET status = 'approved', processed_at = NOW(), processed_by = :processed_by WHERE id = :id";
                        $update_stmt = $db->prepare($update_request);
                        $update_stmt->bindParam(':processed_by', $current_user['id']);
                        $update_stmt->bindParam(':id', $request_id);
                        $update_stmt->execute();

                        // Create notification for player
                        $notification_query = "INSERT INTO notifications (user_id, title, message, type)
                                              VALUES (:user_id, 'Welcome to the Team!',
                                              'Your request to join " . $team['name'] . " has been approved!', 'success')";
                        $notification_stmt = $db->prepare($notification_query);
                        $notification_stmt->bindParam(':user_id', $request['player_id']);
                        $notification_stmt->execute();

                        showMessage($request['first_name'] . " " . $request['last_name'] . " has been added to the team!", "success");
                    } else {
                        showMessage("Failed to add player to team!", "error");
                    }
                }
            } else { // reject
                $update_request = "UPDATE registration_requests SET status = 'rejected', processed_at = NOW(), processed_by = :processed_by WHERE id = :id";
                $update_stmt = $db->prepare($update_request);
                $update_stmt->bindParam(':processed_by', $current_user['id']);
                $update_stmt->bindParam(':id', $request_id);
                $update_stmt->execute();

                // Create notification for player
                $notification_query = "INSERT INTO notifications (user_id, title, message, type)
                                      VALUES (:user_id, 'Request Update',
                                      'Your request to join " . $team['name'] . " has been declined.', 'info')";
                $notification_stmt = $db->prepare($notification_query);
                $notification_stmt->bindParam(':user_id', $request['player_id']);
                $notification_stmt->execute();

                showMessage("Request has been rejected.", "info");
            }
        }
    }

    elseif (isset($_POST['remove_member'])) {
        $member_id = $_POST['member_id'];
        $player_id = $_POST['player_id'];

        // Don't allow removing the team owner
        if ($player_id == $team['owner_id']) {
            showMessage("Cannot remove team owner from the team!", "error");
        } else {
            $remove_query = "UPDATE team_members SET status = 'inactive' WHERE id = :id";
            $remove_stmt = $db->prepare($remove_query);
            $remove_stmt->bindParam(':id', $member_id);

            if ($remove_stmt->execute()) {
                // Create notification for removed player
                $notification_query = "INSERT INTO notifications (user_id, title, message, type)
                                      VALUES (:user_id, 'Team Update',
                                      'You have been removed from " . $team['name'] . ".', 'info')";
                $notification_stmt = $db->prepare($notification_query);
                $notification_stmt->bindParam(':user_id', $player_id);
                $notification_stmt->execute();

                showMessage("Player removed from team successfully!", "success");
            } else {
                showMessage("Failed to remove player!", "error");
            }
        }
    }

    elseif (isset($_POST['update_member'])) {
        $member_id = $_POST['member_id'];
        $position = trim($_POST['position']);
        $jersey_number = $_POST['jersey_number'] ?: null;

        $update_member_query = "UPDATE team_members SET position = :position, jersey_number = :jersey_number WHERE id = :id";
        $update_member_stmt = $db->prepare($update_member_query);
        $update_member_stmt->bindParam(':position', $position);
        $update_member_stmt->bindParam(':jersey_number', $jersey_number);
        $update_member_stmt->bindParam(':id', $member_id);

        if ($update_member_stmt->execute()) {
            showMessage("Player information updated successfully!", "success");
        } else {
            showMessage("Failed to update player information!", "error");
        }
    }
}

// Get team members with detailed information
$members_query = "SELECT tm.*, u.first_name, u.last_name, u.username, u.email, u.phone,
                         ps.matches_played, ps.goals, ps.assists, ps.yellow_cards, ps.red_cards
                  FROM team_members tm
                  JOIN users u ON tm.player_id = u.id
                  LEFT JOIN player_stats ps ON tm.player_id = ps.player_id AND ps.team_id = tm.team_id
                  WHERE tm.team_id = :team_id AND tm.status = 'active'
                  ORDER BY tm.joined_at ASC";
$members_stmt = $db->prepare($members_query);
$members_stmt->bindParam(':team_id', $team_id);
$members_stmt->execute();
$members = $members_stmt->fetchAll(PDO::FETCH_ASSOC);

// Get pending registration requests
$requests_query = "SELECT rr.*, u.first_name, u.last_name, u.username, u.email, u.phone
                   FROM registration_requests rr
                   JOIN users u ON rr.player_id = u.id
                   WHERE rr.team_id = :team_id AND rr.status = 'pending'
                   ORDER BY rr.created_at DESC";
$requests_stmt = $db->prepare($requests_query);
$requests_stmt->bindParam(':team_id', $team_id);
$requests_stmt->execute();
$requests = $requests_stmt->fetchAll(PDO::FETCH_ASSOC);

// Get team's upcoming matches
$upcoming_matches_query = "SELECT m.*, ht.name as home_team, at.name as away_team, v.name as venue_name, v.address as venue_address
                          FROM matches m
                          JOIN teams ht ON m.home_team_id = ht.id
                          JOIN teams at ON m.away_team_id = at.id
                          LEFT JOIN venues v ON m.venue_id = v.id
                          WHERE (m.home_team_id = :team_id OR m.away_team_id = :team_id)
                          AND m.status = 'scheduled'
                          AND m.match_date >= NOW()
                          ORDER BY m.match_date ASC";
$upcoming_matches_stmt = $db->prepare($upcoming_matches_query);
$upcoming_matches_stmt->bindParam(':team_id', $team_id);
$upcoming_matches_stmt->execute();
$upcoming_matches = $upcoming_matches_stmt->fetchAll(PDO::FETCH_ASSOC);

// Get recent match results
$recent_matches_query = "SELECT m.*, ht.name as home_team, at.name as away_team, v.name as venue_name
                        FROM matches m
                        JOIN teams ht ON m.home_team_id = ht.id
                        JOIN teams at ON m.away_team_id = at.id
                        LEFT JOIN venues v ON m.venue_id = v.id
                        WHERE (m.home_team_id = :team_id OR m.away_team_id = :team_id)
                        AND m.status = 'completed'
                        ORDER BY m.match_date DESC
                        LIMIT 5";
$recent_matches_stmt = $db->prepare($recent_matches_query);
$recent_matches_stmt->bindParam(':team_id', $team_id);
$recent_matches_stmt->execute();
$recent_matches = $recent_matches_stmt->fetchAll(PDO::FETCH_ASSOC);

// Calculate team statistics
$total_matches_played = $team['wins'] + $team['draws'] + $team['losses'];
$win_percentage = $total_matches_played > 0 ? round(($team['wins'] / $total_matches_played) * 100, 1) : 0;
$total_goals_scored = array_sum(array_column($members, 'goals'));
$avg_goals_per_match = $total_matches_played > 0 ? round($total_goals_scored / $total_matches_played, 1) : 0;
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage <?php echo htmlspecialchars($team['name']); ?> - Sports League</title>
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }

        body {
            font-family: 'Arial', sans-serif;
            background: #f8f9fa;
            color: #333;
            line-height: 1.6;
        }

        .hero-section {
            background: linear-gradient(135deg, #343a40, #495057);
            color: white;
            padding: 3rem 2rem;
            position: relative;
            overflow: hidden;
        }

        .hero-section::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            background: url('data:image/svg+xml,<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 100 100"><circle cx="20" cy="20" r="2" fill="rgba(255,255,255,0.1)"/><circle cx="80" cy="40" r="1.5" fill="rgba(255,255,255,0.1)"/><circle cx="40" cy="80" r="1" fill="rgba(255,255,255,0.1)"/></svg>') repeat;
        }

        .hero-content {
            max-width: 1200px;
            margin: 0 auto;
            position: relative;
            z-index: 2;
        }

        .team-header {
            display: flex;
            justify-content: space-between;
            align-items: flex-start;
            flex-wrap: wrap;
            gap: 2rem;
        }

        .team-info {
            flex: 1;
            min-width: 300px;
        }

        .team-logo {
            width: 80px;
            height: 80px;
            border-radius: 50%;
            background: linear-gradient(135deg, #007bff, #28a745);
            color: white;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 2rem;
            font-weight: bold;
            margin-bottom: 1rem;
            box-shadow: 0 4px 8px rgba(0,0,0,0.3);
        }

        .team-title {
            font-size: 2.5rem;
            margin-bottom: 0.5rem;
            text-shadow: 2px 2px 4px rgba(0,0,0,0.3);
        }

        .team-subtitle {
            font-size: 1.2rem;
            opacity: 0.9;
            margin-bottom: 1rem;
        }

        .team-meta {
            display: flex;
            gap: 2rem;
            flex-wrap: wrap;
        }

        .meta-item {
            text-align: center;
        }

        .meta-label {
            font-size: 0.8rem;
            opacity: 0.8;
            text-transform: uppercase;
            letter-spacing: 0.5px;
        }

        .meta-value {
            font-size: 1.1rem;
            font-weight: bold;
            margin-top: 0.25rem;
        }

        .permission-badge {
            padding: 0.5rem 1rem;
            border-radius: 25px;
            font-size: 0.9rem;
            font-weight: bold;
            text-transform: uppercase;
        }

        .owner-badge { background: #ffc107; color: black; }
        .member-badge { background: #28a745; color: white; }
        .admin-badge { background: #dc3545; color: white; }

        .quick-stats {
            background: rgba(255,255,255,0.1);
            border-radius: 8px;
            padding: 1.5rem;
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(120px, 1fr));
            gap: 1rem;
            margin-top: 2rem;
        }

        .quick-stat {
            text-align: center;
        }

        .quick-stat .number {
            font-size: 1.8rem;
            font-weight: bold;
            margin-bottom: 0.25rem;
        }

        .quick-stat .label {
            font-size: 0.9rem;
            opacity: 0.9;
        }

        .container {
            max-width: 1200px;
            margin: -3rem auto 2rem;
            padding: 0 2rem;
            position: relative;
            z-index: 10;
        }

        .content-tabs {
            background: white;
            border-radius: 12px;
            box-shadow: 0 4px 6px rgba(0,0,0,0.1);
            overflow: hidden;
        }

        .tab-nav {
            display: flex;
            background: #f8f9fa;
            border-bottom: 1px solid #dee2e6;
        }

        .tab-nav button {
            flex: 1;
            padding: 1rem;
            border: none;
            background: transparent;
            cursor: pointer;
            font-weight: 600;
            color: #666;
            transition: all 0.3s ease;
            position: relative;
        }

        .tab-nav button.active {
            background: white;
            color: #343a40;
            border-bottom: 3px solid #343a40;
        }

        .tab-nav button:hover:not(.active) {
            background: #e9ecef;
            color: #333;
        }

        .tab-content {
            display: none;
            padding: 2rem;
        }

        .tab-content.active {
            display: block;
        }

        .members-table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 1rem;
        }

        .members-table th,
        .members-table td {
            padding: 1rem;
            text-align: left;
            border-bottom: 1px solid #eee;
        }

        .members-table th {
            background: #f8f9fa;
            font-weight: 600;
            color: #333;
            position: sticky;
            top: 0;
        }

        .members-table tr:hover {
            background: #f8f9fa;
        }

        .player-info {
            display: flex;
            align-items: center;
            gap: 0.75rem;
        }

        .player-avatar {
            width: 40px;
            height: 40px;
            border-radius: 50%;
            background: linear-gradient(135deg, #343a40, #495057);
            color: white;
            display: flex;
            align-items: center;
            justify-content: center;
            font-weight: bold;
            font-size: 0.9rem;
        }

        .player-details h4 {
            margin: 0;
            font-size: 1rem;
        }

        .player-details small {
            color: #666;
            display: block;
        }

        .position-badge {
            background: #e9ecef;
            color: #495057;
            padding: 0.25rem 0.75rem;
            border-radius: 12px;
            font-size: 0.75rem;
            font-weight: bold;
        }

        .captain-badge {
            background: #ffc107;
            color: black;
        }

        .stats-summary {
            display: flex;
            gap: 1rem;
            font-size: 0.85rem;
            color: #666;
        }

        .stat-item {
            display: flex;
            flex-direction: column;
            align-items: center;
        }

        .stat-number {
            font-weight: bold;
            color: #343a40;
        }

        .action-buttons {
            display: flex;
            gap: 0.25rem;
            flex-wrap: wrap;
        }

        .btn {
            display: inline-block;
            padding: 0.5rem 1rem;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            font-size: 0.8rem;
            font-weight: 600;
            text-decoration: none;
            transition: all 0.3s ease;
            text-transform: uppercase;
            letter-spacing: 0.5px;
        }

        .btn-primary { background: #007bff; color: white; }
        .btn-primary:hover { background: #0056b3; }

        .btn-success { background: #28a745; color: white; }
        .btn-success:hover { background: #1e7e34; }

        .btn-warning { background: #ffc107; color: black; }
        .btn-warning:hover { background: #e0a800; }

        .btn-danger { background: #dc3545; color: white; }
        .btn-danger:hover { background: #c82333; }

        .btn-info { background: #17a2b8; color: white; }
        .btn-info:hover { background: #138496; }

        .btn-secondary { background: #6c757d; color: white; }
        .btn-secondary:hover { background: #545b62; }

        .btn-lg { padding: 0.75rem 1.5rem; font-size: 1rem; }
        .btn-sm { padding: 0.4rem 0.8rem; font-size: 0.75rem; }

        .request-card {
            background: #f8f9fa;
            border: 1px solid #dee2e6;
            border-radius: 8px;
            padding: 1.5rem;
            margin-bottom: 1rem;
            transition: all 0.3s ease;
        }

        .request-card:hover {
            background: white;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
        }

        .request-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 1rem;
        }

        .request-player {
            display: flex;
            align-items: center;
            gap: 1rem;
        }

        .request-date {
            font-size: 0.9rem;
            color: #666;
        }

        .request-details {
            margin-bottom: 1rem;
        }

        .request-message {
            background: white;
            padding: 1rem;
            border-radius: 6px;
            border-left: 4px solid #007bff;
            margin: 1rem 0;
        }

        .request-actions {
            display: flex;
            gap: 0.5rem;
        }

        .match-card {
            background: #f8f9fa;
            border: 1px solid #dee2e6;
            border-radius: 8px;
            padding: 1rem;
            margin-bottom: 1rem;
            transition: all 0.3s ease;
        }

        .match-card:hover {
            background: white;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
        }

        .match-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 0.5rem;
        }

        .match-date {
            font-weight: bold;
            color: #343a40;
        }

        .match-teams {
            font-size: 1.1rem;
            font-weight: 600;
            text-align: center;
            margin-bottom: 0.5rem;
        }

        .match-result {
            font-size: 1.3rem;
            font-weight: bold;
            text-align: center;
            color: #007bff;
        }

        .match-details {
            display: flex;
            justify-content: space-between;
            font-size: 0.9rem;
            color: #666;
        }

        .modal {
            display: none;
            position: fixed;
            z-index: 1000;
            left: 0;
            top: 0;
            width: 100%;
            height: 100%;
            background: rgba(0,0,0,0.5);
        }

        .modal-content {
            background: white;
            margin: 5% auto;
            padding: 2rem;
            border-radius: 12px;
            width: 90%;
            max-width: 500px;
            box-shadow: 0 4px 6px rgba(0,0,0,0.1);
        }

        .modal-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 1.5rem;
            padding-bottom: 1rem;
            border-bottom: 1px solid #eee;
        }

        .close {
            background: none;
            border: none;
            font-size: 1.5rem;
            cursor: pointer;
            color: #666;
        }

        .form-group {
            margin-bottom: 1rem;
        }

        .form-group label {
            display: block;
            margin-bottom: 0.5rem;
            font-weight: 600;
            color: #333;
        }

        .form-control {
            width: 100%;
            padding: 0.75rem;
            border: 1px solid #ddd;
            border-radius: 4px;
            font-size: 1rem;
        }

        .form-control:focus {
            outline: none;
            border-color: #343a40;
            box-shadow: 0 0 0 2px rgba(52,58,64,0.1);
        }

        .form-row {
            display: flex;
            gap: 1rem;
        }

        .form-row .form-group {
            flex: 1;
        }

        textarea.form-control {
            resize: vertical;
            height: 100px;
        }

        .alert {
            padding: 1rem;
            border-radius: 4px;
            margin-bottom: 1rem;
        }

        .alert-success {
            background: #d4edda;
            color: #155724;
            border: 1px solid #c3e6cb;
        }

        .alert-error {
            background: #f8d7da;
            color: #721c24;
            border: 1px solid #f5c6cb;
        }

        .alert-info {
            background: #d1ecf1;
            color: #0c5460;
            border: 1px solid #bee5eb;
        }

        .alert-warning {
            background: #fff3cd;
            color: #856404;
            border: 1px solid #ffeaa7;
        }

        .empty-state {
            text-align: center;
            padding: 3rem;
            color: #666;
        }

        .empty-state h3 {
            margin-bottom: 1rem;
            color: #999;
        }

        .action-bar {
            background: white;
            padding: 1.5rem;
            border-radius: 8px;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
            margin-bottom: 2rem;
            text-align: center;
        }

        .league-status-alert {
            background: #d1ecf1;
            border: 1px solid #bee5eb;
            color: #0c5460;
            padding: 1rem;
            border-radius: 8px;
            margin-bottom: 2rem;
        }

        @media (max-width: 768px) {
            .hero-section { padding: 2rem 1rem; }
            .team-header { flex-direction: column; align-items: center; text-align: center; }



                        .team-info { text-align: center; }
            .content-tabs { margin-top: 2rem; }
        }
    </style>
    <script>
        // Script for tab navigation
        function openTab(evt, tabName) {
            const tabs = document.querySelectorAll('.tab-content');
            tabs.forEach(tab => tab.classList.remove('active'));
            document.getElementById(tabName).classList.add('active');

            const buttons = document.querySelectorAll('.tab-nav button');
            buttons.forEach(btn => btn.classList.remove('active'));
            evt.currentTarget.classList.add('active');
        }

        // Script for modal handling
        function openModal(id) {
            document.getElementById(id).style.display = 'block';
        }

        function closeModal(id) {
            document.getElementById(id).style.display = 'none';
        }

        // Close modal when clicking outside content
        window.onclick = function(event) {
            document.querySelectorAll('.modal').forEach(modal => {
                if (event.target == modal) {
                    modal.style.display = 'none';
                }
            });
        }
    </script>
</head>
<body>

<?php
// Display success/error messages
if (isset($_SESSION['message'])) {
    $msg = $_SESSION['message'];
    unset($_SESSION['message']);
    echo "<div class='alert alert-{$msg['type']}'>{$msg['text']}</div>";
}
?>

<!-- Hero Section -->
<section class="hero-section">
    <div class="hero-content">
        <div class="team-header">
            <div class="team-info">
                <div class="team-logo"><?php echo strtoupper(substr($team['name'],0,2)); ?></div>
                <h1 class="team-title"><?php echo htmlspecialchars($team['name']); ?></h1>
                <div class="team-subtitle"><?php echo htmlspecialchars($team['league_name']) . " - Season " . htmlspecialchars($team['season']); ?></div>
                <div class="team-meta">
                    <div class="meta-item">
                        <div class="meta-label">Owner</div>
                        <div class="meta-value"><?php echo htmlspecialchars($team['owner_first_name'] . " " . $team['owner_last_name']); ?> (@<?php echo htmlspecialchars($team['owner_username']); ?>)</div>
                        <div class="permission-badge owner-badge">Owner</div>
                    </div>
                    <div class="meta-item">
                        <div class="meta-label">Sport</div>
                        <div class="meta-value"><?php echo htmlspecialchars($team['sport_name']); ?></div>
                        <div class="permission-badge"><?php echo htmlspecialchars($team['league_status']); ?></div>
                    </div>
                </div>
            </div>
            <div>
                <?php if ($can_manage): ?>
                    <button class="btn btn-primary" onclick="openModal('editTeamModal')">Edit Team Info</button>
                <?php endif; ?>
            </div>
        </div>
        <div class="quick-stats">
            <div class="quick-stat">
                <div class="number"><?php echo $team['member_count']; ?></div>
                <div class="label">Players</div>
            </div>
            <div class="quick-stat">
                <div class="number"><?php echo $team['upcoming_matches']; ?></div>
                <div class="label">Upcoming Matches</div>
            </div>
            <div class="quick-stat">
                <div class="number"><?php echo $team['completed_matches']; ?></div>
                <div class="label">Past Matches</div>
            </div>
            <div class="quick-stat">
                <div class="number"><?php echo $team['pending_requests']; ?></div>
                <div class="label">Pending Requests</div>
            </div>
        </div>
    </div>
</section>

<div class="container">
    <div class="content-tabs">
        <!-- Tabs Navigation -->
        <div class="tab-nav">
            <button class="active" onclick="openTab(event, 'members')">Members</button>
            <button onclick="openTab(event, 'requests')">Requests</button>
            <button onclick="openTab(event, 'matches')">Matches</button>
            <button onclick="openTab(event, 'stats')">Statistics</button>
        </div>

        <!-- Members Tab -->
        <div id="members" class="tab-content active">
            <?php if (empty($members)): ?>
                <div class="empty-state">
                    <h3>No members found</h3>
                    <?php if ($can_manage): ?>
                        <button class="btn btn-success" onclick="openModal('addMemberModal')">Add Player</button>
                    <?php endif; ?>
                </div>
            <?php else: ?>
                <table class="members-table">
                    <thead>
                        <tr>
                            <th>Player</th>
                            <th>Position</th>
                            <th>Jersey #</th>
                            <th>Joined At</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($members as $member): ?>
                            <tr>
                                <td>
                                    <div class="player-info">
                                        <div class="player-avatar"><?php echo strtoupper(substr($member['first_name'],0,1)); ?></div>
                                        <div class="player-details">
                                            <h4><?php echo htmlspecialchars($member['first_name'] . ' ' . $member['last_name']); ?></h4>
                                            <small>@<?php echo htmlspecialchars($member['username']); ?></small>
                                            <small><?php echo htmlspecialchars($member['email']); ?></small>
                                        </div>
                                    </div>
                                </td>
                                <td>
                                    <span class="position-badge"><?php echo htmlspecialchars($member['position']); ?></span>
                                </td>
                                <td>
                                    <?php echo htmlspecialchars($member['jersey_number'] ?? 'N/A'); ?>
                                </td>
                                <td><?php echo date('Y-m-d', strtotime($member['joined_at'])); ?></td>
                                <td>
                                    <div class="action-buttons">
                                        <?php if ($can_manage): ?>
                                            <button class="btn btn-info btn-sm" onclick="openModal('editMemberModal<?php echo $member['id']; ?>')">Edit</button>
                                            <form method="POST" style="display:inline;">
                                                <input type="hidden" name="member_id" value="<?php echo $member['id']; ?>">
                                                <input type="hidden" name="player_id" value="<?php echo $member['player_id']; ?>">
                                                <button type="submit" name="remove_member" class="btn btn-danger btn-sm" onclick="return confirm('Remove this player?')">Remove</button>
                                            </form>
                                        <?php endif; ?>
                                    </div>
                                </td>
                            </tr>
                            <!-- Edit Member Modal -->
                            <div id="editMemberModal<?php echo $member['id']; ?>" class="modal">
                                <div class="modal-content">
                                    <div class="modal-header">
                                        <h3>Edit Player Info</h3>
                                        <button class="close" onclick="closeModal('editMemberModal<?php echo $member['id']; ?>')">&times;</button>
                                    </div>
                                    <form method="POST">
                                        <input type="hidden" name="member_id" value="<?php echo $member['id']; ?>">
                                        <input type="hidden" name="player_id" value="<?php echo $member['player_id']; ?>">
                                        <div class="form-group">
                                            <label for="position<?php echo $member['id']; ?>">Position</label>
                                            <input type="text" id="position<?php echo $member['id']; ?>" name="position" value="<?php echo htmlspecialchars($member['position']); ?>" class="form-control" required>
                                        </div>
                                        <div class="form-group">
                                            <label for="jersey_number<?php echo $member['id']; ?>">Jersey Number</label>
                                            <input type="number" id="jersey_number<?php echo $member['id']; ?>" name="jersey_number" value="<?php echo htmlspecialchars($member['jersey_number']); ?>" class="form-control">
                                        </div>
                                        <button type="submit" name="update_member" class="btn btn-success">Update</button>
                                    </form>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            <?php endif; ?>
        </div>

        <!-- Requests Tab -->
        <div id="requests" class="tab-content" style="display:none;">
            <?php if (empty($requests)): ?>
                <div class="empty-state">
                    <h3>No pending requests</h3>
                </div>
            <?php else: ?>
                <?php foreach ($requests as $request): ?>
                    <div class="request-card">
                        <div class="request-header">
                            <div>
                                <strong><?php echo htmlspecialchars($request['first_name'] . ' ' . $request['last_name']); ?></strong> (@<?php echo htmlspecialchars($request['username']); ?>)
                                <div class="request-date"><?php echo date('Y-m-d H:i', strtotime($request['created_at'])); ?></div>
                            </div>
                            <div>
                                <?php if ($can_manage): ?>
                                    <form method="POST" style="display:inline;">
                                        <input type="hidden" name="request_id" value="<?php echo $request['id']; ?>">
                                        <button type="submit" name="process_request" value="approve" class="btn btn-success btn-sm" onclick="return confirm('Approve this request?')">Approve</button>
                                        <button type="submit" name="process_request" value="reject" class="btn btn-danger btn-sm" onclick="return confirm('Reject this request?')">Reject</button>
                                    </form>
                                <?php endif; ?>
                            </div>
                        </div>
                        <div class="request-details">
                            <p>Requested Position: <?php echo htmlspecialchars($request['preferred_position']); ?></p>
                            <p>Message: <?php echo htmlspecialchars($request['message']); ?></p>
                        </div>
                        <div class="request-message">
                            <strong>Additional Info:</strong> <?php echo htmlspecialchars($request['additional_info']); ?>
                        </div>
                    </div>
                <?php endforeach; ?>
            <?php endif; ?>
        </div>

        <!-- Matches Tab -->
        <div id="matches" class="tab-content" style="display:none;">
            <h3>Upcoming Matches</h3>
            <?php if (empty($upcoming_matches)): ?>
                <div class="empty-state">
                    <h3>No upcoming matches scheduled</h3>
                </div>
            <?php else: ?>
                <?php foreach ($upcoming_matches as $match): ?>
                    <div class="match-card">
                        <div class="match-header">
                            <div class="match-date"><?php echo date('Y-m-d H:i', strtotime($match['match_date'])); ?></div>
                        </div>
                        <div class="match-teams">
                            <?php echo htmlspecialchars($match['home_team']); ?> vs <?php echo htmlspecialchars($match['away_team']); ?>
                        </div>
                        <div class="match-result">
                            <?php echo isset($match['result']) ? htmlspecialchars($match['result']) : 'Scheduled'; ?>
                        </div>
                        <div class="match-details">
                            <div>Venue: <?php echo htmlspecialchars($match['venue_name'] ?? 'TBD'); ?></div>
                        </div>
                    </div>
                <?php endforeach; ?>
            <?php endif; ?>

            <h3 class="mt-4">Recent Matches</h3>
            <?php if (empty($recent_matches)): ?>
                <div class="empty-state">
                    <h3>No recent matches</h3>
                </div>
            <?php else: ?>
                <?php foreach ($recent_matches as $match): ?>
                    <div class="match-card">
                        <div class="match-header">
                            <div class="match-date"><?php echo date('Y-m-d H:i', strtotime($match['match_date'])); ?></div>
                        </div>
                        <div class="match-teams">
                            <?php echo htmlspecialchars($match['home_team']); ?> vs <?php echo htmlspecialchars($match['away_team']); ?>
                        </div>
                        <div class="match-result" style="color:<?php echo ($match['result_type'] == 'win') ? '#28a745' : (($match['result_type'] == 'loss') ? '#dc3545' : '#ffc107'); ?>;">
                            <?php echo htmlspecialchars($match['result']); ?>
                        </div>
                        <div class="match-details">
                            <div>Venue: <?php echo htmlspecialchars($match['venue_name'] ?? 'TBD'); ?></div>
                        </div>
                    </div>
                <?php endforeach; ?>
            <?php endif; ?>
        </div>

        <!-- Statistics Tab -->
        <div id="stats" class="tab-content" style="display:none;">
            <h3>Team Statistics</h3>
            <ul>
                <li>Total Matches Played: <?php echo $total_matches_played; ?></li>
                <li>Win Percentage: <?php echo $win_percentage; ?>%</li>
                <li>Total Goals Scored: <?php echo $total_goals_scored; ?></li>
                <li>Average Goals per Match: <?php echo $avg_goals_per_match; ?></li>
            </ul>
            <!-- Additional detailed stats can be added here -->
        </div>
    </div>
</div>

<!-- Modals for Editing Team Info -->
<div id="editTeamModal" class="modal">
    <div class="modal-content">
        <div class="modal-header">
            <h3>Edit Team Information</h3>
            <button class="close" onclick="closeModal('editTeamModal')">&times;</button>
        </div>
        <form method="POST">
            <div class="form-group">
                <label for="teamName">Name</label>
                <input type="text" id="teamName" name="name" value="<?php echo htmlspecialchars($team['name']); ?>" class="form-control" required>
            </div>
            <div class="form-group">
                <label for="teamDescription">Description</label>
                <textarea id="teamDescription" name="description" class="form-control"><?php echo htmlspecialchars($team['description']); ?></textarea>
            </div>
            <button type="submit" name="update_team" class="btn btn-success">Update Team</button>
        </form>
    </div>
</div>

<!-- Modal for Adding Player -->
<div id="addMemberModal" class="modal">
    <div class="modal-content">
        <div class="modal-header">
            <h3>Add Player to Team</h3>
            <button class="close" onclick="closeModal('addMemberModal')">&times;</button>
        </div>
        <form method="POST" action="add_member.php">
            <div class="form-group">
                <label for="playerSelect">Select Player</label>
                <select id="playerSelect" name="player_id" class="form-control" required>
                    <?php
                    // Fetch players not in team
                    $players_query = "SELECT u.id, u.first_name, u.last_name, u.username FROM users u
                                      WHERE u.role = 'player' AND u.id NOT IN (SELECT player_id FROM team_members WHERE team_id = :team_id AND status='active')";
                    $players_stmt = $db->prepare($players_query);
                    $players_stmt->bindParam(':team_id', $team_id);
                    $players_stmt->execute();
                    $players = $players_stmt->fetchAll(PDO::FETCH_ASSOC);
                    foreach ($players as $player) {
                        echo "<option value='{$player['id']}'>{$player['first_name']} {$player['last_name']} (@{$player['username']})</option>";
                    }
                    ?>
                </select>
            </div>
            <div class="form-group">
                <label for="preferredPosition">Preferred Position</label>
                <input type="text" id="preferredPosition" name="preferred_position" class="form-control" required>
            </div>
            <button type="submit" class="btn btn-success">Add Player</button>
        </form>
    </div>
</div>

<!-- Additional Modals for notifications or other actions can be added here -->

</body>
</html>